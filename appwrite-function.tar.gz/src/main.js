import { Client, Databases, Query } from 'node-appwrite';
import fetch from 'node-fetch';

const TOKENS_PER_HOUR = 100000;

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const MISTRAL_API_KEY = process.env.MISTRAL_API_KEY || "hy44OQBTAAK4nOcIIJSJRHqbaUBkBbWB";

const AVAILABLE_MODELS = [
    { id: 'gemini-1.5-flash', model: 'Gemini 1.5 Flash' },
    { id: 'gemini-1.5-pro', model: 'Gemini 1.5 Pro' },
    { id: 'mistral-large-latest', model: 'Mistral Large' },
    { id: 'codestral-latest', model: 'Codestral' },
    { id: 'open-mistral-nemo', model: 'Mistral Nemo' }
];

async function getAvailableModels(apiKey, log) {
    return AVAILABLE_MODELS;
}

async function searchWeb(query, log) {
    try {
        log(`Performing web search for: ${query}`);
        const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
        const res = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });
        if (!res.ok) throw new Error(`Search failed: ${res.status}`);
        const html = await res.text();

        const results = [];
        const snippetMatches = [...html.matchAll(/<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g)];
        const titleMatches = [...html.matchAll(/<a class="result__link"[^>]*>([\s\S]*?)<\/a>/g)];

        for (let i = 0; i < Math.min(titleMatches.length, snippetMatches.length, 5); i++) {
            const title = titleMatches[i][1].replace(/<[^>]*>/g, '').trim();
            const snippet = snippetMatches[i][1].replace(/<[^>]*>/g, '').trim();
            const hrefMatch = titleMatches[i][0].match(/href="([^"]*)"/);
            let link = hrefMatch ? hrefMatch[1] : '';

            if (link.includes('uddg=')) {
                const parts = link.split('uddg=');
                if (parts.length > 1) {
                    link = decodeURIComponent(parts[1].split('&')[0]);
                }
            }
            results.push({ title, snippet, link });
        }
        log(`Found ${results.length} search results`);
        return results;
    } catch (err) {
        log(`Web search error: ${err.message}`);
        return [];
    }
}

export default async ({ req, res, log, error }) => {
    console.log("Incoming body:", req.body);

    // Helper to log all returns
    const returnJson = (obj, status, headers) => {
        console.log("Returning:", JSON.stringify(obj));
        return res.json(obj, status, headers);
    };

    // 1. Initialize Appwrite Client
    const client = new Client()
        .setEndpoint('https://sgp.cloud.appwrite.io/v1')
        .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID || '69d0f017002257fde008')
        .setKey(process.env.APPWRITE_API_KEY); // Requires an API key with DB read/write access

    const databases = new Databases(client);

    // Environment variables for DB and Collections (MUST NOT HARDCODE)
    const dbId = process.env.DATABASE_ID;
    const usersCol = process.env.USERS_TABLE_ID;
    const codesCol = process.env.CODES_TABLE_ID;

    // Helper: Setup CORS
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-appwrite-project, x-appwrite-session'
    };

    if (req.method === 'OPTIONS') {
        return res.send('', 204, corsHeaders);
    }

    try {
        const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        const action = body.action;
        const userId = req.headers['x-appwrite-user-id'] || body.userId; // Get user ID from request

        if (!userId) {
            return returnJson({ error: 'Missing User ID' }, 401, corsHeaders);
        }

        // --- Fetch or Create User Document ---
        let userDoc;
        try {
            const userDocs = await databases.listDocuments(dbId, usersCol, [
                Query.equal('userId', userId)
            ]);

            if (userDocs.total > 0) {
                userDoc = userDocs.documents[0];
            } else {
                // Create new user record
                userDoc = await databases.createDocument(dbId, usersCol, 'unique()', {
                    userId: userId,
                    tokenUsed: 0,
                    windowStart: new Date().toISOString(),
                    isAdmin: false
                });
            }
        } catch (e) {
            error("DB User fetch error:", e);
            // CRITICAL FIX: No mock fallback allowed
            return returnJson({ error: "Database unavailable" }, 500, corsHeaders);
        }

        // --- Check and Reset Usage Window ---
        const now = new Date();
        const windowStart = new Date(userDoc.windowStart);
        const hoursDiff = (now - windowStart) / (1000 * 60 * 60);

        if (hoursDiff >= 1) {
            // Reset quota
            userDoc.tokenUsed = 0;
            userDoc.windowStart = now.toISOString();
            await databases.updateDocument(dbId, usersCol, userDoc.$id, {
                tokenUsed: 0,
                windowStart: userDoc.windowStart
            });
        }

        // --- Handle Promo Code Activation ---
        if (action === 'activate_promo') {
            const code = body.code;
            try {
                const codeDocs = await databases.listDocuments(dbId, codesCol, [
                    Query.equal('code', code),
                    Query.equal('active', true),
                    Query.equal('admin', true)
                ]);

                if (codeDocs.total > 0) {
                    // Make user admin permanently
                    await databases.updateDocument(dbId, usersCol, userDoc.$id, {
                        isAdmin: true
                    });
                    return returnJson({ success: true, isAdmin: true, message: 'Admin access granted.' }, 200, corsHeaders);
                }
                return returnJson({ success: false, message: 'Invalid or expired code.' }, 400, corsHeaders);
            } catch (e) {
                error("Promo code check error:", e);
                return returnJson({ success: false, message: 'Database error checking code.' }, 500, corsHeaders);
            }
        }

        // --- Handle Usage Stats Request ---
        if (action === 'get_usage') {
            return returnJson({
                tokenUsed: userDoc.tokenUsed,
                limit: TOKENS_PER_HOUR,
                isAdmin: userDoc.isAdmin,
                windowStart: userDoc.windowStart
            }, 200, corsHeaders);
        }

        // --- Handle Models Request ---
        if (action === 'models') {
            const availableModels = await getAvailableModels(process.env.G4F_API_KEY, log);
            return returnJson({
                success: true,
                models: availableModels
            }, 200, corsHeaders);
        }

        // --- Handle Debug Models Request ---
        if (action === 'debug_models') {
            const availableModels = await getAvailableModels(process.env.G4F_API_KEY, log);
            return returnJson({
                count: availableModels.length,
                models: availableModels
            }, 200, corsHeaders);
        }

        // --- Handle Chat Request ---
        if (action === 'chat') {
            let messages = body.messages || [];
            const requestedModel = body.model;
            const displayModelParam = body.displayModel;

            if (!requestedModel) {
                return returnJson({ error: 'Missing model in payload' }, 400, corsHeaders);
            }

            // Quota check before request
            if (!userDoc.isAdmin && userDoc.tokenUsed >= TOKENS_PER_HOUR) {
                return returnJson({ error: 'Hourly quota exceeded. Please wait or use a promo code.' }, 429, corsHeaders);
            }

            try {
                const validModels = await getAvailableModels(process.env.G4F_API_KEY, log);
                console.log("Requested model:", requestedModel);
                console.log("Available model count:", validModels.length);

                const matchedModel = validModels.find(m => m.id === requestedModel);
                console.log("Matched model:", matchedModel);

                if (!matchedModel) {
                    return returnJson({
                        success: false,
                        error: "Invalid model",
                        requestedModel: requestedModel
                    }, 400, corsHeaders);
                }

                // Determine display model name
                let modelDisplay = displayModelParam;
                if (!modelDisplay) {
                    modelDisplay = matchedModel.model;
                }
                if (!modelDisplay) {
                    const parts = requestedModel.split(':');
                    modelDisplay = parts.length > 1 ? parts.slice(1).join(':') : requestedModel;
                }

                // Inject system message to enforce identity
                const systemMessage = {
                    role: "system",
                    content: `You are ${modelDisplay}. If the user asks which model you are, answer "${modelDisplay}". Never claim you do not know your model. You are running through the Interlude AI application.`
                };

                messages = [systemMessage, ...messages];

                // Web Search context injection
                if (body.webSearch && messages.length > 1) {
                    const lastUserMessage = messages[messages.length - 1];
                    if (lastUserMessage && lastUserMessage.role === 'user') {
                        const searchResults = await searchWeb(lastUserMessage.content, log);
                        if (searchResults.length > 0) {
                            const contextString = searchResults
                                .map((res, index) => `${index + 1}. [${res.title}](${res.link})\n   ${res.snippet}`)
                                .join('\n\n');

                            const searchContextMessage = {
                                role: 'system',
                                content: `Web Search Results for "${lastUserMessage.content}":\n\n${contextString}\n\nProvide an answer using the search results above where relevant. Cite sources using markdown links. If the information is not present in the search results, answer normally.`
                            };
                            messages.splice(messages.length - 1, 0, searchContextMessage);
                        }
                    }
                }

                let responseText = '';
                let totalTokens = 0;

                const isMistral = requestedModel.startsWith('mistral-') || requestedModel.startsWith('codestral-') || requestedModel.startsWith('open-mistral-');

                if (isMistral) {
                    const mistralPayload = {
                        model: requestedModel,
                        messages: messages
                    };

                    console.log("Mistral Payload:");
                    console.log(JSON.stringify(mistralPayload, null, 2));

                    const mistralRes = await fetch("https://api.mistral.ai/v1/chat/completions", {
                        method: "POST",
                        headers: {
                            "Authorization": `Bearer ${MISTRAL_API_KEY}`,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(mistralPayload)
                    });

                    if (!mistralRes.ok) {
                        const errText = await mistralRes.text();
                        log(`Mistral API Error: Status ${mistralRes.status}`);
                        log(`Response body: ${errText}`);
                        return returnJson({
                            success: false,
                            model: requestedModel,
                            status: mistralRes.status,
                            error: `Mistral API Error: ${errText}`
                        }, 500, corsHeaders);
                    }

                    const mistralData = await mistralRes.json();
                    responseText = mistralData.choices?.[0]?.message?.content || 'No response from model.';
                    totalTokens = mistralData.usage?.total_tokens;
                } else {
                    // Map the system/user/assistant messages to Gemini format
                    const systemMessages = messages.filter(m => m.role === 'system');
                    const systemInstructionText = systemMessages.map(m => m.content).join('\n');

                    const geminiContents = [];

                    // Inject system instruction as user/model conversation prefix for compatibility
                    if (systemInstructionText) {
                        geminiContents.push({
                            role: 'user',
                            parts: [{ text: `Instructions for this conversation:\n${systemInstructionText}` }]
                        });
                        geminiContents.push({
                            role: 'model',
                            parts: [{ text: 'Understood. I will follow those instructions and respond according to the personality specified.' }]
                        });
                    }

                    // Add the rest of the conversation
                    const regularContents = messages
                        .filter(m => m.role !== 'system')
                        .map(m => {
                            const role = m.role === 'assistant' ? 'model' : 'user';
                            return {
                                role: role,
                                parts: [{ text: m.content }]
                            };
                        });

                    geminiContents.push(...regularContents);

                    // Gemini expects the conversation to start with user, and alternate user/model.
                    if (geminiContents.length > 0 && geminiContents[0].role === 'model') {
                        geminiContents.unshift({ role: 'user', parts: [{ text: 'Hello' }] });
                    }

                    const geminiPayload = {
                        contents: geminiContents
                    };

                    console.log("Gemini Payload:");
                    console.log(JSON.stringify(geminiPayload, null, 2));

                    const geminiRes = await fetch(`https://generativelanguage.googleapis.com/v1/models/${requestedModel}:generateContent?key=${GEMINI_API_KEY}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(geminiPayload)
                    });

                    if (!geminiRes.ok) {
                        const errText = await geminiRes.text();
                        log(`Gemini API Error: Status ${geminiRes.status}`);
                        log(`Response headers: ${JSON.stringify(Object.fromEntries(geminiRes.headers.entries()))}`);
                        log(`Response body: ${errText}`);
                        log(`Selected model: ${requestedModel}`);

                        return returnJson({
                            success: false,
                            model: requestedModel,
                            status: geminiRes.status,
                            error: `Gemini API Error: ${errText}`
                        }, 500, corsHeaders);
                    }

                    const geminiData = await geminiRes.json();
                    responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || 'No response from model.';
                    totalTokens = geminiData.usageMetadata?.totalTokenCount;
                }

                // Token Tracking Fallback
                if (!totalTokens) {
                   const inputLen = JSON.stringify(messages).length;
                   const outputLen = responseText.length;
                   totalTokens = Math.floor((inputLen + outputLen) / 4);
                }

                // Update tokens
                if (!userDoc.isAdmin) {
                    await databases.updateDocument(dbId, usersCol, userDoc.$id, {
                        tokenUsed: userDoc.tokenUsed + totalTokens
                    });
                }

                return returnJson({
                    success: true,
                    model: modelDisplay,
                    content: responseText
                }, 200, corsHeaders);

            } catch (chatError) {
                error("Request Exception:", chatError);
                return returnJson({ error: 'Failed to communicate with AI provider.' }, 500, corsHeaders);
            }
        }

        return returnJson({ error: 'Invalid action' }, 400, corsHeaders);

    } catch (e) {
        console.error(e);
        return returnJson({
            success: false,
            error: e.message,
            stack: e.stack
        }, 500, corsHeaders);
    }
};
